var defaultClickURL = [{
	productLabel: 	"default",
	productURL: 	"https://www.diy.com/?utm_source=dbm&utm_campaign=trading-brand-deliveryoptions-mar22&utm_medium=display-prospecting&utm_content=merkle&utm_term=animated"
}]

var products = [
	{
		productLabel: "exit1",
		productURL: "",
	},
	{
		productLabel: "exit2",
		productURL: "",
	},
	{		
		productLabel: "exit3",
		productURL: "",
	},
	{		
		productLabel: "exit4",
		productURL: "",
	}		
];

var config = (function () {
var module = {}
return module
})();